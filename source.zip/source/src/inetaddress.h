#ifndef INETADDRESS_H
#define INETADDRESS_H

#include <arpa/inet.h>
#include <string>

#include "logger.h"

namespace
{
static std::string DEFAULT_IP = INADDR_ANY;
static constexpr uint16_t DEFAULT_PORT = 10088;
}

class InetAddress
{
public:
    InetAddress(const std::string &ip = DEFAULT_IP, uint16_t port = DEFAULT_PORT);
    sockaddr_in get_addr() const;
private:
    sockaddr_in addr;
};

#endif