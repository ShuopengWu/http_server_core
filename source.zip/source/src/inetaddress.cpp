#include "inetaddress.h"

InetAddress::InetAddress(const std::string &ip, uint16_t port)
{
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    if (ip.empty())
    {
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
    }
    else
    {
        if (!inet_pton(AF_INET, ip.c_str(), &addr.sin_addr))
        {
            logger::logger::instance().show_waring_log("Invalid IP address provided: " + ip + ". Defaulting to INADDR_ANY.");
            addr.sin_addr.s_addr = htonl(INADDR_ANY);
        }
    }
}

sockaddr_in InetAddress::get_addr() const
{
    return addr;
}
